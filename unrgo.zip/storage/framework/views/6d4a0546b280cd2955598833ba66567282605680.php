<!DOCTYPE html>
<html lang="uk">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">

    <link rel="apple-touch-icon" sizes="180x180" href="<?php echo e(asset('apple-touch-icon.png')); ?>">
    <link rel="icon" type="image/png" sizes="32x32" href="<?php echo e(asset('favicon-32x32.png')); ?>">
    <link rel="icon" type="image/png" sizes="16x16" href="<?php echo e(asset('favicon-16x16.png')); ?>">
    <link rel="manifest" href="<?php echo e(asset('site.webmanifest')); ?>">
    <link rel="mask-icon" href="<?php echo e(asset('safari-pinned-tab.svg')); ?>" color="#5bbad5">
    <meta name="msapplication-TileColor" content="#da532c">
    <meta name="theme-color" content="#ffffff">

    <link rel="stylesheet" href="<?php echo e(asset('app/libs/libs.min.css?v=' . random_int(1000, 9999))); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('app/css-min/main.min.css?v='. random_int(1000, 9999))); ?>">
    <script src="<?php echo e(asset('app/libs/libs.min.js')); ?>"></script>

    <title>
        <?php if(View::hasSection('title')): ?>
            <?php echo $__env->yieldContent('title'); ?>
        <?php else: ?>
            UnReal GO
        <?php endif; ?>
    </title>

</head>
<body>
    
    <?php echo $__env->make("includes.header", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    
    <main class="content">
        <div class="container">
            <?php echo $__env->yieldContent('content'); ?>
        </div>
    </main>

    
    <?php echo $__env->make("includes.footer", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    
    <?php echo $__env->make("includes.background", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    
    <?php echo $__env->make("includes.modal", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

</body>
    <script>
        
        const csrfToken = "<?php echo e(csrf_token()); ?>";

        
        let baseURL = "<?php echo e(route("home")); ?>";
        let likeProductURL = "<?php echo e(route("user.product.like")); ?>";
        let likeUrl = "<?php echo e(route('user.comment.like')); ?>";

    </script>
    <?php echo $__env->yieldPushContent('js'); ?>
</html>
<?php /**PATH C:\OpenServer\domains\unreal_go\resources\views/layouts/base.blade.php ENDPATH**/ ?>