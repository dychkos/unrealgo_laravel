<?php $__env->startSection('content'); ?>
    <?php if($errors->any()): ?>
        <div class="required_alert">
            <ul>
                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li><?php echo e($error); ?></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        </div>
    <?php endif; ?>
    <div class="admin-content__header">
        <div class="admin-content__title h1">Orders</div>
        <div class="admin-content__navigation">
            <a class="admin-content__add" href="<?php echo e(route('user.admin.index', 'orders')); ?>">
                <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                    <path d="M22.9611 10.9611H3.54692L8.17942 6.32827C8.58525 5.92268 8.58525 5.26472 8.17942 4.85919C7.77358 4.45335 7.11563 4.45335 6.71039 4.85919L0.304377 11.2653C-0.101459 11.6709 -0.101459 12.3289 0.304377 12.7344L6.71039 19.1408C6.91325 19.3438 7.17911 19.4452 7.44491 19.4452C7.7107 19.4452 7.97656 19.3438 8.17942 19.1408C8.58525 18.7352 8.58525 18.0773 8.17942 17.6718L3.54692 13.0388H22.9611C23.5348 13.0388 24 12.5736 24 11.9999C24 11.4262 23.5348 10.9611 22.9611 10.9611Z" fill="#FDFFBA"/>
                </svg>
            </a>
        </div>
    </div>
    <form class="admin-one admin-form"
          action="<?php echo e(route('user.admin.orders.update', $order->id)); ?>"
          enctype="multipart/form-data"
          method="POST">
        <?php echo csrf_field(); ?>

        <?php if(session()->has('message')): ?>
            <div class="success-message">
                <?php echo e(session()->get('message')); ?>

            </div>
        <?php endif; ?>

        <div class="admin-row">
            <div class="admin-input form-input">
                <div class="dropdown">
                    <?php $__errorArgs = ["status_id"];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <div class="required_alert"><?php echo e($message); ?></div>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    <label for="status">Вкажіть статус замовлення :</label>
                    <select name="status_id" id="status" class="select" class="<?php echo e($errors->has('status_id') ? 'required' : ''); ?>">
                        <?php $__currentLoopData = $statuses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $status): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php if($order->status->id === $status->id): ?>
                                <option value="<?php echo e($status->id); ?>" selected ><?php echo e($status->title); ?></option>
                            <?php else: ?>
                                <option value="<?php echo e($status->id); ?>"><?php echo e($status->title); ?></option>
                            <?php endif; ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>
            </div>
        </div>
        <div class="admin-row row">
            <div class="col-3">
                <div class="h6">
                    Дата
                </div>
                <div class="p">
                    <?php echo e($order->created_at->format('Y-m-d')); ?>

                </div>
            </div>
            <div class="col-3">
                <div class="h6">
                    ФІО покупця:
                </div>
                <div class="p">
                    <?php echo e($order->data_name); ?>

                </div>
            </div>
            <div class="col-6">
                <div class="h6">
                    Номер заказа
                </div>
                <div class="p">
                    № <?php echo e($order->id); ?>

                </div>
            </div>
        </div>
        <div class="admin-row">
          <div class="col-6">
              <div class="h6">
                  Сумма заказа
              </div>
              <div class="p">
                  <?php echo e($order->total_price); ?>  UAH
              </div>
          </div>
            <div class="col-6">
                <div class="h6">
                    Статус
                </div>
                <div class="p">
                    <?php echo e($order->status->title); ?>

                </div>
            </div>
        </div>
        <div class="admin-row">
            <div class="col-6">
                <div class="h6">
                    Адреса для доставки:
                </div>
                <div class="p">
                    місто: <?php echo e($order->city); ?>

                </div>
            </div>
            <div class="col-6">
                <div class="h6">
                    Відділення
                </div>
                <div class="p">
                    <?php echo e($order->department); ?>

                </div>
            </div>
        </div>
        <div class="admin-row d-flex flex-column mt-5">
            <div class="order-final__body-title row">
                <div class="order-final__body-label col-4 p-light">Товар</div>
                <div class="order-final__body-label col-4 p-light">Кількість</div>
                <div class="order-final__body-label col-4 p-light">Ціна</div>
            </div>
            <div class="order-final__item-list">
                <?php $__currentLoopData = $order->items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="order-final__item row">
                        <div class="order-final__product col-4">
                            <div class="order-final__image">
                                <img src="<?php echo e($item->product->images->first()
                                    ? asset($item->product->images->first()->filename)
                                    : asset("app/img/test.png")); ?>" alt="Product">
                            </div>
                            <div class="order-final__name"><?php echo e($item->product->title); ?></div>
                        </div>
                        <div class="order-final__count col-4"><?php echo e($item->count); ?></div>
                        <div class="order-final__price col-4"><?php echo e($item->product->currentPrice()); ?> UAH</div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>
        <div class="admin-row">
            <button type="submit" class="btn btn_primary">Зберегти</button>
        </div>
    </form>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('js'); ?>
    <script src="<?php echo e(asset('app/js/libs/Select.js')); ?>"></script>
    <script src="<?php echo e(asset('app/js/admin.js')); ?>"></script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make("admin.layout.admin", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\OpenServer\domains\unreal_go\resources\views/admin/orders/index.blade.php ENDPATH**/ ?>