

<?php $__env->startSection('content'); ?>
    <section class="order-history">
        <div class="order-history__title page-title h1">Історія замовлення</div>
        <div class="order-history__body card">
            <?php if(count($orders) < 1): ?>
                <div class="order-history__empty empty">
                    <img src="<?php echo e(asset("app/img/empty.png")); ?>" class="empty__image" alt="Empty">
                    <h3 class="empty__title h3">Ще не зробили жодного замовлення</h3>
                    <a class="btn btn_primary h6" href="<?php echo e(route("store.index")); ?>" style="color: #fff">
                        Перейти до каталогу
                    </a>
                </div>
            <?php else: ?>
                <div class="order-history__header">
                    <div class="order-history__quick-nav quick-nav">
                        <div class="quick-nav__item quick-nav__item_active" data-nav="all" >Всі замовлення <span class="count">( <?php echo e(count($orders)); ?> )</span></div>
                        <div class="quick-nav__item <?php echo e(count($waiting) > 0 ? "" : "quick-nav__item_disabled"); ?>" data-nav="waiting">В обробці <span class="count">( <?php echo e(count($waiting)); ?> )</span></div>
                        <div class="quick-nav__item <?php echo e(count($ready) > 0 ? "" : "quick-nav__item_disabled"); ?>" data-nav="ready">Завершені <span class="count">( <?php echo e(count($ready)); ?> )</span></div>
                        <div class="quick-nav__item  <?php echo e(count($canceled) > 0 ? "" : "quick-nav__item_disabled"); ?>" data-nav="canceled">Скасовані <span class="count">(<?php echo e(count($canceled )); ?> )</span></div>
                    </div>
                    <div class="order-history__help-link help-link">
                        Допомога
                    </div>
                </div>
                <div class="order-history__order-list nav-active" id="all">
                    <?php $__currentLoopData = $orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="order-history__order order-final <?php echo e($order->status->value == "canceled" ? "order-final_inActive" : ""); ?>">
                            <div class="order-final__title">
                                <div class="order-final__info">
                                    <div class="order-final__info-label p-light">
                                        Дата
                                    </div>
                                    <div class="order-final__info-value p">
                                        <?php echo e($order->created_at->format('Y-m-d')); ?>

                                    </div>
                                </div>
                                <div class="order-final__info">
                                    <div class="order-final__info-label p-light">
                                        Номер замовлення
                                    </div>
                                    <div class="order-final__info-value p">
                                        № <?php echo e($order->id); ?>

                                    </div>
                                </div>
                                <div class="order-final__info">
                                    <div class="order-final__info-label p-light">
                                        Сума замовлення
                                    </div>
                                    <div class="order-final__info-value p">
                                        <?php echo e($order->total_price); ?>  UAH
                                    </div>
                                </div>
                                <div class="order-final__info">
                                    <div class="order-final__info-label p-light">
                                        Статус
                                    </div>
                                    <div class="order-final__info-value p">
                                        <?php echo e($order->status->title); ?>

                                    </div>
                                </div>
                            </div>
                            <div class="order-final__body">
                                <div class="order-final__body-title row">
                                    <div class="order-final__body-label col-4 p-light">Товар</div>
                                    <div class="order-final__body-label col-4 p-light">Кількість</div>
                                    <div class="order-final__body-label col-4 p-light">Ціна</div>
                                </div>
                                <div class="order-final__item-list">
                                    <?php $__currentLoopData = $order->items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <div class="order-final__item row">
                                            <div class="order-final__product col-4">
                                                <div class="order-final__image">
                                                    <img src="<?php echo e($item->product->images->first()
                                    ? asset($item->product->images->first()->filename)
                                    : asset("app/img/test.png")); ?>" alt="Product">
                                                </div>
                                                <div class="order-final__name"><?php echo e($item->product->title); ?></div>
                                            </div>
                                            <div class="order-final__count col-4"><?php echo e($item->count); ?></div>
                                            <div class="order-final__price col-4"><?php echo e($item->product->currentPrice()); ?> UAH</div>
                                        </div>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </div>
                            </div>
                            <div class="order-final__button <?php echo e($order->status->value == "waiting" ? "" : "d-none"); ?>">
                                <a href="<?php echo e(route("store.cancel-order", $order->id)); ?>" class="btn btn_danger h6">
                                    Скасувати замовлення
                                </a>
                            </div>

                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
                <div class="order-history__order-list" id="waiting" style="display: none">
                    <?php $__currentLoopData = $waiting; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="order-history__order order-final">
                            <div class="order-final__title">
                                <div class="order-final__info">
                                    <div class="order-final__info-label p-light">
                                        Дата
                                    </div>
                                    <div class="order-final__info-value p">
                                        <?php echo e($order->created_at->format('Y-m-d')); ?>

                                    </div>
                                </div>
                                <div class="order-final__info">
                                    <div class="order-final__info-label p-light">
                                        Номер замовлення
                                    </div>
                                    <div class="order-final__info-value p">
                                        № <?php echo e($order->id); ?>

                                    </div>
                                </div>
                                <div class="order-final__info">
                                    <div class="order-final__info-label p-light">
                                        Сума замовлення
                                    </div>
                                    <div class="order-final__info-value p">
                                        <?php echo e($order->total_price); ?>  UAH
                                    </div>
                                </div>
                                <div class="order-final__info">
                                    <div class="order-final__info-label p-light">
                                        Статус
                                    </div>
                                    <div class="order-final__info-value p">
                                        <?php echo e($order->status->title); ?>

                                    </div>
                                </div>
                            </div>
                            <div class="order-final__body">
                                <div class="order-final__body-title row">
                                    <div class="order-final__body-label col-4 p-light">Товар</div>
                                    <div class="order-final__body-label col-4 p-light">Количество</div>
                                    <div class="order-final__body-label col-4 p-light">Цена</div>
                                </div>
                                <div class="order-final__item-list">
                                    <?php $__currentLoopData = $order->items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <div class="order-final__item row">
                                            <div class="order-final__product col-4">
                                                <div class="order-final__image">
                                                    <img src="<?php echo e($item->product->images->first()
                                    ? asset($item->product->images->first()->filename)
                                    : asset("app/img/test.png")); ?>" alt="Product">
                                                </div>
                                                <div class="order-final__name"><?php echo e($item->product->title); ?></div>
                                            </div>
                                            <div class="order-final__count col-4"><?php echo e($item->count); ?></div>
                                            <div class="order-final__price col-4"><?php echo e($item->product->currentPrice()); ?> UAH</div>
                                        </div>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </div>
                            </div>
                            <div class="order-final__button <?php echo e($order->status->value == "waiting" ? "" : "d-none"); ?>">
                                <a href="<?php echo e(route("store.cancel-order", $order->id)); ?>" class="btn btn_danger h4">
                                    Скасувати замовлення
                                </a>
                            </div>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
                <div class="order-history__order-list" id="ready" style="display: none">
                    <?php $__currentLoopData = $ready; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="order-history__order order-final">
                            <div class="order-final__title">
                                <div class="order-final__info">
                                    <div class="order-final__info-label p-light">
                                        Дата
                                    </div>
                                    <div class="order-final__info-value p">
                                        <?php echo e($order->created_at->format('Y-m-d')); ?>

                                    </div>
                                </div>
                                <div class="order-final__info">
                                    <div class="order-final__info-label p-light">
                                        Номер замовлення
                                    </div>
                                    <div class="order-final__info-value p">
                                        № <?php echo e($order->id); ?>

                                    </div>
                                </div>
                                <div class="order-final__info">
                                    <div class="order-final__info-label p-light">
                                        Сума замовлення
                                    </div>
                                    <div class="order-final__info-value p">
                                        <?php echo e($order->total_price); ?>  UAH
                                    </div>
                                </div>
                                <div class="order-final__info">
                                    <div class="order-final__info-label p-light">
                                        Статус
                                    </div>
                                    <div class="order-final__info-value p">
                                        <?php echo e($order->status->title); ?>

                                    </div>
                                </div>
                            </div>
                            <div class="order-final__body">
                                <div class="order-final__body-title row">
                                    <div class="order-final__body-label col-4 p-light">Товар</div>
                                    <div class="order-final__body-label col-4 p-light">Количество</div>
                                    <div class="order-final__body-label col-4 p-light">Цена</div>
                                </div>
                                <div class="order-final__item-list">
                                    <?php $__currentLoopData = $order->items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <div class="order-final__item row">
                                            <div class="order-final__product col-4">
                                                <div class="order-final__image">
                                                    <img src="<?php echo e($item->product->images->first()
                                    ? asset($item->product->images->first()->filename)
                                    : asset("app/img/test.png")); ?>" alt="Product">
                                                </div>
                                                <div class="order-final__name"><?php echo e($item->product->title); ?></div>
                                            </div>
                                            <div class="order-final__count col-4"><?php echo e($item->count); ?></div>
                                            <div class="order-final__price col-4"><?php echo e($item->product->currentPrice()); ?> UAH</div>
                                        </div>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </div>
                            </div>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
                <div class="order-history__order-list" id="canceled" style="display: none">
                    <?php $__currentLoopData = $canceled; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="order-history__order order-final">
                            <div class="order-final__title">
                                <div class="order-final__info">
                                    <div class="order-final__info-label p-light">
                                        Дата
                                    </div>
                                    <div class="order-final__info-value p">
                                        <?php echo e($order->created_at->format('Y-m-d')); ?>

                                    </div>
                                </div>
                                <div class="order-final__info">
                                    <div class="order-final__info-label p-light">
                                        Номер замовлення
                                    </div>
                                    <div class="order-final__info-value p">
                                        № <?php echo e($order->id); ?>

                                    </div>
                                </div>
                                <div class="order-final__info">
                                    <div class="order-final__info-label p-light">
                                        Сума замовлення
                                    </div>
                                    <div class="order-final__info-value p">
                                        <?php echo e($order->total_price); ?>  UAH
                                    </div>
                                </div>
                                <div class="order-final__info">
                                    <div class="order-final__info-label p-light">
                                        Статус
                                    </div>
                                    <div class="order-final__info-value p">
                                        <?php echo e($order->status->title); ?>

                                    </div>
                                </div>
                            </div>
                            <div class="order-final__body">
                                <div class="order-final__body-title row">
                                    <div class="order-final__body-label col-4 p-light">Товар</div>
                                    <div class="order-final__body-label col-4 p-light">Количество</div>
                                    <div class="order-final__body-label col-4 p-light">Цена</div>
                                </div>
                                <div class="order-final__item-list">
                                    <?php $__currentLoopData = $order->items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <div class="order-final__item row">
                                            <div class="order-final__product col-4">
                                                <div class="order-final__image">
                                                    <img src="<?php echo e($item->product->images->first()
                                    ? asset($item->product->images->first()->filename)
                                    : asset("app/img/test.png")); ?>" alt="Product">
                                                </div>
                                                <div class="order-final__name"><?php echo e($item->product->title); ?></div>
                                            </div>
                                            <div class="order-final__count col-4"><?php echo e($item->count); ?></div>
                                            <div class="order-final__price col-4"><?php echo e($item->product->currentPrice()); ?> UAH</div>
                                        </div>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </div>
                            </div>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            <?php endif; ?>
        </div>
    </section>
<?php $__env->stopSection(); ?>

<?php if (! $__env->hasRenderedOnce('240e71ac-6eef-4eae-bd4f-4933ac6df3e7')): $__env->markAsRenderedOnce('240e71ac-6eef-4eae-bd4f-4933ac6df3e7'); ?>
    <?php $__env->startPush('js'); ?>
        <script src="<?php echo e(asset('app/js-min/orders.min.js?v=' . random_int(1000, 9999))); ?>"></script>
    <?php $__env->stopPush(); ?>
<?php endif; ?>


<?php echo $__env->make('layouts.base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\OpenServer\domains\unreal_go\resources\views/user/order-history.blade.php ENDPATH**/ ?>