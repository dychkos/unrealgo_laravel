import MainController from "./main";

export class DefaultPage extends MainController {
	static init() {
		super.init();
	}
}

DefaultPage.init();
