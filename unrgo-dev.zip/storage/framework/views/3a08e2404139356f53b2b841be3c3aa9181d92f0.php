<?php $__env->startSection('content'); ?>
    <div class="auth auth_login">
        <div class="auth__title h2">Увійти</div>
        <div class="auth__body">
            <form action="<?php echo e(route('login.login')); ?>" method="POST" class="auth__form auth-form">
                <?php echo csrf_field(); ?>

                <?php $__errorArgs = ["email"];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <div class="required_alert"><?php echo e($message); ?></div>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                <div class="auth-form__item form-input">
                    <input
                        type="email"
                        placeholder="Email"
                        name="email"
                        class="<?php echo e($errors->has('email') ? 'required' : ''); ?>"
                        value="<?php echo e(old('email')); ?>"
                    />
                </div>

                <?php $__errorArgs = ["password"];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <div class="required_alert"><?php echo e($message); ?></div>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                <div class="auth-form__item form-input">
                    <input
                        type="password"
                        placeholder="Пароль"
                        name="password"
                        class="<?php echo e($errors->has('password') ? 'required' : ''); ?>"
                        value="<?php echo e(old('email')); ?>"
                    />
                </div>
                <div class="auth-form__item row">
                    <button type="submit" class="auth-form__submit btn btn_primary h6">
                        Увійти
                    </button>
                    <div class="auth-form__link p mt-3">
                        Ще немає акаунту ? <a class="link" href="<?php echo e(route('register.index')); ?>">Зареєструватись</a>
                    </div>
                </div>
            </form>
        </div>
        <div class="auth__footer">
            <div class="auth__or">
                OR
            </div>
            <div class="auth__footer-text">
                Увійти за допомогою:
            </div>
            <div class="auth__footer-links" style="width: 50px;">
                <a href="<?php echo e(route("google_auth")); ?>" class="auth__footer-link google-link">
                    <svg width="48" height="48" viewBox="0 0 48 48" fill="none" xmlns="http://www.w3.org/2000/svg">
                        <path fill-rule="evenodd" clip-rule="evenodd" d="M0 24C0 10.7452 10.7452 0 24 0C37.2548 0 48 10.7452 48 24C48 37.2548 37.2548 48 24 48C10.7452 48 0 37.2548 0 24ZM23.9654 17.6213C25.9154 17.6213 27.2309 18.4649 27.9809 19.1698L30.9118 16.304C29.1117 14.6284 26.7693 13.6 23.9654 13.6C19.9037 13.6 16.3959 15.9342 14.6881 19.3316C13.9842 20.7413 13.5804 22.3244 13.5804 24C13.5804 25.6756 13.9842 27.2587 14.6881 28.6684L18.0575 26.0569L14.6996 28.6684C16.4074 32.0658 19.9037 34.4 23.9654 34.4C26.7693 34.4 29.1232 33.4756 30.8425 31.8809C32.8041 30.0667 33.935 27.3973 33.935 24.2311C33.935 23.376 33.8657 22.752 33.7157 22.1049H23.9654V25.9644H29.6887C29.5733 26.9236 28.9502 28.368 27.5655 29.3387C26.6885 29.9511 25.5116 30.3787 23.9654 30.3787C21.2191 30.3787 18.8883 28.5644 18.0575 26.0569C17.8382 25.4098 17.7113 24.7164 17.7113 24C17.7113 23.2836 17.8382 22.5902 18.0459 21.9431C18.8883 19.4356 21.2191 17.6213 23.9654 17.6213Z" fill="white"/>
                    </svg>
                </a>





            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php if (! $__env->hasRenderedOnce('3b118c4b-e07e-4368-b1a5-9a52f9782e48')): $__env->markAsRenderedOnce('3b118c4b-e07e-4368-b1a5-9a52f9782e48'); ?>
    <?php $__env->startPush('js'); ?>
        <script src="<?php echo e(asset('app/js-min/auth.min.js?v=' . random_int(1000, 9999))); ?>"></script>
    <?php $__env->stopPush(); ?>
<?php endif; ?>


<?php echo $__env->make('layouts.base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\OpenServer\domains\unreal_go\resources\views/auth/login.blade.php ENDPATH**/ ?>