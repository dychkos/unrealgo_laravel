<?php

return [
    'nova_poshta' => [
        'url' => 'https://api.novaposhta.ua/v2.0/json/',
        'api_key' =>env('NOVA_POSHTA_API', 'aabcf7c7457fed2937fc69e37d77369d')
    ]
];
