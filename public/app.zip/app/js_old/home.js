//Declarations
new Swiper(".swiper", {
    ...sliderOptions,
    navigation: {
        nextEl: ".swiper-button-next",
        prevEl: ".swiper-button-prev",
    }
});