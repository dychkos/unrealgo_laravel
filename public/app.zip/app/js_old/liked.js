/*
* Declaration
* */

new Swiper(".recommended-swiper", {
    ...sliderOptions,navigation: {
        nextEl: "#swiper-button-next-1",
        prevEl: "#swiper-button-prev-1",
    }
});